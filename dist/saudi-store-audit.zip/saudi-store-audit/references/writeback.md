# 当天列组回写与复核

只写本次实际日期（默认Asia/Shanghai，用户已指定的日期时区优先）对应的唯一列组。历史日期组与基础产品列只读。开始前先读daily-columns.md定位当天组。

## 字段决策

| 本次证据 | 当天MSRP | 当天售价 | 当天buy box | 当天Note |
|---|---|---|---|---|
| 在售，有划线价与售价 | 填所记录报价（用户 Chrome 默认选中档）对应的划线价 | 填所记录报价的数字价 | 所记录报价 Shipper/Seller 均为 Amazon.sa 则 1，否则 0 | 卖家为 Amazon Now 或已核实非平台卖家时填sold by名称，Amazon.sa 留空，否则空白 |
| 在售，完整页面确认无划线价 | 留空 | 填所记录报价的数字价 | 按所记录报价主体 | 同上 |
| 明确缺货，包括仍残留数字售价 | 可核实划线价或空白 | 文本OOS | 无当前可售报价则0 | 卖家为 Amazon Now 或已核实非平台卖家时填sold by名称，Amazon.sa 留空，否则空白 |
| Noon显示This product is not available且Status=EOL | 空白 | 空白 | 不适用 | 空白；优先于OOS和卖家规则 |
| Noon显示上述不可用提示但Status无法读取/定位 | 暂不写入 | 暂不写入，不猜OOS | 不适用 | 暂不写入，报告状态核验失败 |
| 主购买框无价格展示（且非缺货） | 全部留空 | 全部留空 | 全部留空 | 全部留空；不翻购买选项找价 |
| 主购买框展示的为二手报价 | 该报价对应划线价或空白 | 展示的二手当前价 | 按主体，Amazon Resale=0 | 卖家为 Amazon Now 或已核实非平台卖家时填sold by名称，Amazon.sa 留空；成色记报告 |
| 缺少商品链接 | 新格留空；旧值仅保留为未核实 | 新格留空，不写OOS；旧值仅保留为未核实 | 新格留空；旧值仅保留为未核实 | 留空；当天已确认由巡店生成的旧Note精确清空，人工/公式冲突保留并报告 |
| 访问失败、未打开商品页、未完成加载 | 新格留空 | 新格留空，不写OOS | 新格留空 | 新格留空，原因写进该格备注；失败行及原因同时记报告；同日已有值按归属规则处理 |
| 卖家/发货方无法确认 | 已核实价格可填 | 已核实价格或OOS可填 | 已知一方非Amazon.sa则0；确实无法判断时留空并记报告 | 仅非平台卖家已核实时填，否则新格留空，未核实项记报告 |

Noon的Status按字段表头定位，不固定列号；同日回写前重读。EOL留空例外要求原链接打开的商品页显示指定不可用提示且该行Status为EOL，EOL但仍在售的商品正常查价。

Amazon先确认Riyadh；以用户登录后的默认视图为准：云端浏览器（Environment 1）已登录用户 Amazon 账号，先确认页眉显示“Hello, Qian”，已登录时直接取页面打开时默认选中的购买方式的价格，不固定优先一次性购买（Amazon.sa）；如果默认选中的是 Amazon Now，即使页面有一性购买选项，也取 Amazon Now 的价格。若发现未登录，不要取匿名浏览器的默认档（匿名默认是 Amazon Now，与用户看到的不一致），也不要按本地配置取值——停止 Amazon 部分的核查，在报告里注明登录已过期、请用户重新登录，等她重新登录后再补跑；Noon 不需要登录，正常进行；不要在巡店中自行重新登录。主购买框无价格展示且非缺货时整行留空。currently unavailable且无当前可售报价才写OOS。所记录报价的Shipper / Seller均为Amazon.sa才填1，否则填0；仍未知不能猜0。

“本次未核实”不能变成0、OOS、确认不存在或历史值。本次生成的Note格子只允许 `sold by <卖家名>`、`N left`、两者组合 `sold by <卖家名>; N left`，或空白；其中卖家名指已核实的非平台卖家或 Amazon Now，Amazon.sa 不写进 Note；页面显示剩余库存标识（如 Only N left in stock）时写 `N left`，数字以页面为准（如仅剩 1 件写 `1 left`）；卖家为 Amazon.sa 或没有实际卖家信息时不写卖家名；不写缺货、OOS、发货方、运费、成色或日期；需人工审核的失败说明写进该格的单元格备注（见异常标注一节），详细证据和失败原因另存报告。商品价不包含另列运费。

## 同日重跑和人工备注

上述“留空”对本日新组天然成立，不需要清空其他日期的数据。若重跑当天唯一已有组：

- 确认无划线价，可精确清空当天由巡店写入的旧MSRP。确认缺货的售价改为OOS，不因没有数字而清空；恢复有货时将当天OOS替换为本次数字售价。
- Noon指定不可用提示且Status=EOL：当天MSRP、Price、Note均应空白；逐格清理本日巡店自动写入内容，历史和基础列不变。新空格不需清空请求；无法证明归属或遇到人工/公式内容时保留并报告冲突，不能宣称已全部留空。
- 缺链接时，当天Note必须留空：写前重读链接元数据和Note原值；只有GO!文字且无实际URL/超链接/公式链接，或确认为缺少商品链接，并且Note有巡店前缀或与本日自动写入日志精确匹配时，逐格清空该自动Note。保留原值、归属和缺链接证据即可，不要求商品页证据。人工、公式或归属不明的Note保留并报告冲突；不能把自动Note保留规则当成缺链接留空规则的例外。
- 其他查证失败保留本日旧值，在报告标记本次未核实；缺链接行价格/Buy Box也仅保留为未核实。不能把保留值算进新查价或新写入数，不往Note写失败说明。
- 本次卖家核实为 Amazon.sa 或完整页面确认无卖家信息时，当天Note应空白；卖家为 Amazon Now 或已核实非平台卖家时，当天Note为sold by名称。卖家仅暂未核实不能据此清掉已有卖家Note，保留但在报告标明本次未核实。
- 当天旧“缺货”、OOS备注、长句或失败说明，归属明确且本次证据充分时，清理或替换为本次实际非平台卖家；缺链接清理按上条的链接与归属证据执行。历史Note原样保留，不批量修订旧日期。
- 清理或替换必须有本日前次写入记录、明确巡店前缀等归属证据；不能只因文字恰为“缺货”就推定为自动备注。人工内容、公式与归属不明的值/Note保留，列为冲突。

## 异常标注（价格标红、黄色高亮与单元格备注）

只写当天组，不改历史组与人工内容，写后随当批回写一起读回复核。

- **当天价格有变动只标红，不写备注、不标黄**：与昨日相比、两日均为数字售价且数值不同时，把当天 Price（Noon）/ Offer Price（Amazon）格的数字字体标红（foregroundColorStyle.rgbColor RGB 1,0,0）；只标售价格，MSRP 格不标红；缺货/OOS 状态变化不标红。Note 格不写价格变动说明。格式请求用 repeatCell，fields 仅为 userEnteredFormat.textFormat.foregroundColorStyle；不要用已废弃的 foregroundColor 字段，用它写出的红字会掉色。标红后读回核实红字确实存在。去掉红字时（例如基准组改变后某行不再算价格变动），把 foregroundColorStyle 设为 {"rgbColor": {}}（空的 rgbColor 对象），恢复默认黑色；不要把 foregroundColorStyle 设成空对象 {}——空对象会让字体变白、数字在表里看不见（2026-11-27 行 17/25 的 399 因此“隐藏”）。去掉后读回核实字体恢复默认色、数值仍在。**字体颜色铁律**：当天组所有数据格的文字一律黑色（foregroundColorStyle {"rgbColor": {}}），只有当天价格变动的 Offer Price 格标红；回写结束后逐格核对当天组字体颜色，凡是 foregroundColorStyle 为空对象 {} 的格子一律改成 {"rgbColor": {}}，读回核实可见；红色只允许出现在当天价格变动的 Offer Price 格上。
- **卖家变化、buy box 变化不写备注、不标黄**：Note 格按正常规则写当前卖家（如 `sold by <卖家名>`，Amazon.sa 除外）或空白，buy box 格写当前值；变化通过与昨日组对比可见，不再另写说明。
- **唯一标黄加备注的情形是需人工审核**：页面加载失败、被拦截、未核实的行，当天 Note 格背景填黄色（RGB 1,1,0），并在该格单元格备注写明原因，如「页面加载失败，未核实」「页面被拦截，未核实」。其他情形一律不写备注、不标黄。黄色格式请求用 repeatCell，fields 仅为 userEnteredFormat.backgroundColor。
- 已确认缺货只在售价写 `OOS`，不写备注、不标黄；EOL 三项留空，不标注。Noon 只适用价格变动与打不开两项。
- 列宽合适：写完所有数据后，把当天 Note 列宽调到刚好完整显示格子里最长一条文本；只按格子里的文字算，单元格备注里的文字不占列宽，也不要设得过宽。先执行自动列宽，再按最长文本核对：按字符估算所需宽度——中文每字约 13px、英文/数字每字约 7px、阿拉伯文每字约 8px，另加 10px 边距；自动列宽给出的值若小于估算值，以估算值为准（自动列宽会低估中文宽度）；不够加宽、太宽收窄，最后读回列宽核实。只做自动列宽不可靠，必须再核对一次。列宽以列里当前最长一条文本为准，用户在巡店后又往 Note 列里加了更长的文字时，也按同样方法把列宽加宽到能完整显示。
- **MSRP / Offer Price / buy box 列宽固定**：Amazon 当天组的 MSRP 列宽 136px、Offer Price 列宽 132px、buy box 列宽 132px（以 2026/11/22 组 DK:DN 为准）；新建日期组时用 updateDimensionProperties 按此固定值设置，不随内容自动调整；复用组若宽度被改动，恢复为此固定值；设置后读回列宽核实。Note 列仍按最长文本动态调整，不固定。
- 备注写入用 updateCells，fields 包含 note；只改备注时不碰值与格式，需要同时改值时 fields 用 userEnteredValue,note。只标注本次实际遇到的需人工审核行，不写推测。
- 新建组复制样式时不带入上一组的黄色高亮、红色字体与单元格备注；回写前检查当天 Note 列与价格列，残留的上一组高亮/红色字体/备注要清除（只清当天组，不动历史组），清除后读回复核。还要检查当天组数据行（第 3 行起）的数字格式不得为 DATE：复制样式可能把上一组空单元格残留的日期格式带进来，导致数字售价粘贴到别处时显示为日期；发现 DATE 格式就改成 NUMBER（pattern "0"），清除后读回复核。
- **新增产品行先重置格式再写值**：当天产品范围比昨日末行多出新行时（用户新增产品），先把该行在当天组里的格式重置干净再回写：数字格式 NUMBER、底色白色、字体默认色、无单元格备注；重置后读回复核，再写值。不得把上一组或末行之下的残留格式带进新行。
- **收尾清格式**：回写结束、复核完成后，清除当天组内产品末行之下的残留底色：把当天组在最后一行产品之下的单元格背景恢复为白色（repeatCell，fields 仅为 userEnteredFormat.backgroundColor），不留表头色的填充；只清当天组，不动历史组；清除后读回复核。

## 精确单元格操作

依据当天日期组实时计算零基列号，不使用固定F/H/J目标。数字价格和buy box用numberValue，OOS和卖家Note用stringValue，普通数据写入fields只用userEnteredValue；对齐与列宽使用下节独立的精确格式请求。保留售价列原有数字/货币格式，文本OOS仍需读回确认其文本类型与右对齐；验证约束若拒绝文本则报告具体格，不擅自移除验证。

例如某次Noon当天组已定位为L:N：L=MSRP、M=Price、N=Note。该行第3行页面售价89，则只写M3（列索引12）：

```json
{
  "updateCells": {
    "range": {
      "sheetId": 0, "startRowIndex": 2, "endRowIndex": 3,
      "startColumnIndex": 12, "endColumnIndex": 13
    },
    "rows": [{"values": [{"userEnteredValue": {"numberValue": 89}}]}],
    "fields": "userEnteredValue"
  }
}
```

同一位置确认缺货且不属于Noon EOL例外时，M3改用文本，不写数值或Note状态：

```json
{
  "updateCells": {
    "range": {
      "sheetId": 0, "startRowIndex": 2, "endRowIndex": 3,
      "startColumnIndex": 12, "endColumnIndex": 13
    },
    "rows": [{"values": [{"userEnteredValue": {"stringValue": "OOS"}}]}],
    "fields": "userEnteredValue"
  }
}
```

若同日重跑确认本行指定不可用提示且Status=EOL，并已证明M3是当天巡店写入，应记录“M3：原值→空白，EOL例外及归属证据”，再精确清空M3：

```json
{
  "updateCells": {
    "range": {
      "sheetId": 0, "startRowIndex": 2, "endRowIndex": 3,
      "startColumnIndex": 12, "endColumnIndex": 13
    },
    "rows": [{"values": [{}]}],
    "fields": "userEnteredValue"
  }
}
```

这个清空请求没有覆盖L3/N3；EOL例外仍须分别检查并精确处理当天L3/N3，不能因只清空Price就宣称三项均为空。其他日期组不动。只有当天格、归属和页内证据充分且旧值重读一致时才允许清空；新空白格、未知字段或人工内容不执行清空。日期组与行号均是示例，不能直接用作实时批次。

## 当天组显示格式

新建组、同日重跑和失败恢复都执行；实时定位当天列，不把某次运行的G/H/J列号写死。数据类型和格式分别处理：OOS仍是文本，数字售价仍是数值。

1. 对当天Price / Offer Price从首个产品行到本次最后产品行，用repeatCell仅设置userEnteredFormat.horizontalAlignment=RIGHT，fields仅为userEnteredFormat.horizontalAlignment。包括数字、OOS及空白正文；不覆盖字段/日期行、MSRP或buy box，不修改数字格式、字体、底色、边框、验证或值。每批后读回OOS的effectiveFormat.horizontalAlignment应为RIGHT；轮次结束复核整个售价正文。
2. 对当天Note从首个产品行到本次最后产品行，用repeatCell仅设置userEnteredFormat.textDirection=LEFT_TO_RIGHT、userEnteredFormat.horizontalAlignment=LEFT，fields仅为userEnteredFormat.textDirection,userEnteredFormat.horizontalAlignment。新建、复用及同日重跑均执行，包括空白正文，不覆盖Note表头、日期行或其他列。有卖家的备注以英文前缀sold by开始，店铺原名随后显示；只有 `N left` 的备注只写该文本；阿语店名内部保持自然阿语阅读顺序。保留字符串原文，不翻译、不反转店名字母/单词、不插入LRM/RLM或其他隐藏方向控制字符，不把整表改成从左到右。
3. 每轮回写结束、旧自动Note清理完成后，检查当天Note正文。存在文字时保持单行，若已有WRAP则只对当天Note正文把wrapStrategy改为OVERFLOW_CELL，fields只用userEnteredFormat.wrapStrategy；先完成上述Note方向/左对齐，再对该一个Note列使用autoResizeDimensions，按完整卖家名适配；随后按当天最长一条格子文本核对列宽：按字符估算所需宽度——中文每字约 13px、英文/数字每字约 7px、阿拉伯文每字约 8px，另加 10px 边距；自动列宽给出的值若小于估算值，以估算值为准（自动列宽会低估中文宽度，不能只信它）；不够加宽、太宽收窄，读回列宽核实（只按格子里的文字算，单元格备注不占列宽）。列宽以列里当前最长一条文本为准——用户在巡店后又往 Note 列里加了更长的文字时，也按同样方法把列宽加宽到能完整显示。保留字号、行高和字符串，不改为省略号、不靠溢出到邻列显示。
4. 当天Note正文全空时不自动缩窄：复用组保留现有宽度，新组沿用模板宽度。历史Note列和其他列不参与自动列宽，也不整表autofit。日期合并范围与表头样式不变。
5. 数值请求、售价水平对齐请求、Note方向/左对齐请求、单行显示请求和单列列宽请求分别记录；复核允许变化仅为这些字段和目标范围。列宽/格式修复不得计为新增网页核验或新查价。Google Sheets正常缩放下检查OOS、最长英文Note、阿拉伯文Note及相邻列，确认sold by在左且店名随后完整单行可见。

例如当天Noon组已定位为L:N，产品行3至55，仅统一Price正文的右对齐：

```json
{
  "repeatCell": {
    "range": {"sheetId": 0, "startRowIndex": 2, "endRowIndex": 55, "startColumnIndex": 12, "endColumnIndex": 13},
    "cell": {"userEnteredFormat": {"horizontalAlignment": "RIGHT"}},
    "fields": "userEnteredFormat.horizontalAlignment"
  }
}
```

同组Note=N，先统一Note正文的方向和左对齐：

```json
{
  "repeatCell": {
    "range": {"sheetId": 0, "startRowIndex": 2, "endRowIndex": 55, "startColumnIndex": 13, "endColumnIndex": 14},
    "cell": {"userEnteredFormat": {"textDirection": "LEFT_TO_RIGHT", "horizontalAlignment": "LEFT"}},
    "fields": "userEnteredFormat.textDirection,userEnteredFormat.horizontalAlignment"
  }
}
```

Note=N且正文有内容时，单列适配请求为：

```json
{
  "autoResizeDimensions": {
    "dimensions": {"sheetId": 0, "dimension": "COLUMNS", "startIndex": 13, "endIndex": 14}
  }
}
```

示例行列均须用实时当天组替换。自动列宽返回成功仍要检查实际渲染，不能据此宣称文字一定适配。

## 批次闭环

1. 创建或复用当天组并读回复核日期与字段，保存所有历史组和基础列基线。
2. 对每个产品保存原始/实际URL、编号、页内证据、价格显示状态、库存、seller/shipper、成色、运费和时间；Noon另存Status表头位置、行状态及EOL例外依据。
3. 5–15行一批，写前重读日期、目标行及原表链接、Noon的Status和目标旧值，防止列组移动、换链接、状态变更或并发覆盖。
4. 写后逐格读回数字、文本OOS、空白及卖家Note，检查OOS与数字售价右对齐、Note从左到右/左对齐且视觉上sold by先于店名、缺链接自动Note留空及EOL行三项留空是否成立。返回成功标志不能替代数据复核；结果不明先读回再补写，不盲目重试整批。复核结论以实际读回的单元格值为准，不能用计划写入的值代替；读回发现不一致时纠正该格并在报告中说明。
5. 对比历史组与基础列仍一致，格式变化仅限新组创建及当天售价正文右对齐、Note从左到右、左对齐和单行显示；列宽变化仅限有内容的当天Note列。轮次结束完成单列自动适配与实际显示复核，核对未把昨日值复制到当天。
6. 分开统计新增/复用列组、完整页面核验、EOL跳过、部分字段核验、实际写入及复核成功、普通OOS缺货、缺链接、失败和人工冲突；EOL自动清理格数另报，EOL不混入普通OOS/失败数。Noon临时拒绝访问按 [SKILL.md 的重试规则](../SKILL.md#noon) 处理；分别报告重试恢复和仍待核实的行。没有变化可报告“已核验，无需改值”，不能虚增写入数。

逐行记录包含run_date/timezone、当天组范围、sheetId/row/product_id、original_url/observed_url、checked_at、字段present/absent/unknown、stock_status、Noon Status及EOL例外、before/after、归属、写入和复核状态。详细记录和失败行只进巡店记录/报告，Note仅用于实际非平台卖家。
